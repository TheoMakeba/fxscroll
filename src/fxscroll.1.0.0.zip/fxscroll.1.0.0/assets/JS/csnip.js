document.addEventListener("DOMContentLoaded", function(){
	csnip().docparse();
});